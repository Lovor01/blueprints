<?php

add_action( 'enqueue_block_editor_assets', function() {
	$deps = require( __DIR__ . '/build/tweak-close-icon.asset.php' );
	wp_enqueue_script(
		'iconchanges',
		get_stylesheet_directory_uri() . '/build/tweak-close-icon.js' ,
		array(),
		$deps['version']
	);
} );

// add_action( 'render_block_makeiteasy/popup', function($content) {
// 	$svg = file_get_contents( __DIR__ . '/block-editor-tweaks/assets/close-button-dark.svg' );
// 	return preg_replace(
// 		'~(<button.*class="makeiteasy-popup-close".*? >).*(</button>)~m',
// "$1$svg$2",
// $content
// );
// } );